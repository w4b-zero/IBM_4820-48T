﻿3M Touch Systems, Inc.
MT 7.14 Software for Windows Vista/Server 2008/7/8/10

Version 7.14.9, June 28, 2016
Copyright 1991-2016 3M.
All rights reserved.

---------------------------------
PRODUCT SUMMARY
---------------------------------
MT 7 Software, a member of the MicroTouch(tm) Software Suite, provides
unified driver support for MicroTouch touch technologies over a wide
range of operating systems. This product includes a driver, a control
panel, a calibration tool, and a touch monitor that provides enhanced
touch features on your Windows Vista, Server 2008, 7, 8, and 10
operating systems.

---------------------------------
FEATURES AND ENHANCEMENTS
---------------------------------
* Added support for new PCT devices.

---------------------------------
SYSTEM REQUIREMENTS
---------------------------------
Hardware Prerequisites

* MT 7 runs on most computers that run on 32-bit or 64-bit versions of
  the Windows Vista, Windows Server 2008, Windows 7, Windows 8, or
  Windows 10 operating systems.
* One or more of the following MicroTouch touch screen controllers:
  - MicroTouch EX serial, USB, or HID controllers
  - MicroTouch DX serial or USB controllers
  - MicroTouch PX serial or USB controllers
  - MicroTouch RX serial or USB controllers
  - MicroTouch SX serial controllers
* Depending on the touch screen, either a serial (COM) port or a USB
  port is required.

Software Prerequisites

* MT 7 requires a 32-bit or 64-bit version of the Windows Vista, Windows
  Server 2008, Windows 7, Windows 8, or Windows 10 operating systems.
* Note that 3M's multitouch products work well with Windows 7, 8, and 10
  without the MT 7 for Windows driver. Unless you need a special feature
  of MT 7, do not install this software on these operating systems.
* The help file requires a PDF viewer.

---------------------------------
INSTALLATION INSTRUCTIONS
---------------------------------
* Using Windows Explorer, browse to the software distribution and
  double-click on the Setup program to start the installation. If you
  downloaded the distribution, unzip the file beforehand. Follow the
  instructions given by the Setup program.
* If this is a new installation, you have two options: Full and Custom.
  Use the Custom option to select which features you want. The Full
  option installs all features.
* The installer then asks for your preference for driver options. You
  can choose only one.
  - The digitizer option makes your touch screens appear as touch
    devices, enabling some gestures for single-touch devices and the
	full range of touch support for PX devices.
  - The HID mouse option makes your touch screens appear as mice using
    Microsoft’s HID interface. This disables touch gesture support and
	treats PX devices as single-touch devices.
  - The legacy mouse option makes your touch screens appear as mice
    using Microsoft’s old serial mouse interface. This disables touch
	gesture support and treats PX devices as single-touch devices.
* If you already have MT 7 for Windows installed, one of two things
  happens. If you are installing a different version of MT 7 for
  Windows, the installer does not prompt you and uses your old choices.
  If you are installing the same version, the installer asks you to
  choose features and driver support.
* During installation, you will get messages about finding new hardware.
  This is the MT 7 software registering your touch controllers.

---------------------------------
SILENT INSTALLATION
---------------------------------
* The first step in producing a silent installation is to record your
  standard installation. Open a command line window and set your working
  directory to the directory containing the MT 7 for Windows setup
  program. Issue the command "setup /saveinf=<name>.inf", replacing
  <name> with a valid file name. Run the installation normally.
* When the installation finishes, it creates the recording file that you
  specified in the command line, in the directory from where you ran the
  setup program. 
* To run the silent installation, simply issue the command "setup
  /loadinf=<name>.inf /verysilent". This replays the installation you
  recorded above and suppresses any dialog boxes from the setup program.
* Note that the silent installation may fail if the installer reacts
  differently than when it was recorded. For example, if you record an
  installation updating the same version of MT 7 for Windows, the
  recording may not work on an upgrade or new installation. You should
  test the silent installation on all expected configurations.

---------------------------------
MULTIPLE MONITOR SUPPORT
---------------------------------
This version of the control panel introduces support for multiple
monitors and touch screen systems. At this time, this new feature does
not support "splitter" systems where two monitors appear as a single
monitor to the Windows operating system.

To see if your system uses video splitters, open the Windows Control
Panel and select the Display option. Go to the "Settings" tab. If the
number of monitors shown is different from the number of physical
monitors, then you have a splitter system.

This is only a problem if each of the monitors shows a different part
of the desktop. If each monitor shows the same part of the desktop,
the MT 7 for Windows software can support this.

The MT 7 for Windows software can support such systems with additional
manual configuration. Contact your Field Application Engineer or
Technical Support representative at 3M Touch Systems, Inc., for
additional information.

---------------------------------
HIDING THE CURSOR
---------------------------------
In some applications, it is desirable to hide the cursor. The MT 7 for
Windows software provides a blank cursor file so that you can hide the
cursor.

During installation, select either the "Full" or "Custom" installation
option. If you select "Custom", go to the "Utilities and Tools"
section and select the "Blank Cursor" option. This puts a file,
BLANK.CUR, into the MT 7 for Windows directory.

Copy this file into your Windows "Cursors" directory. There should be
other files with the extension "cur" in this directory.

Open the Windows Control Panel and select the Mouse option. Select the
"Pointer" tab and click on the "Browse" button. Browse to the Windows
cursor directory if not already there and select the BLANK.CUR file.
Click on "OK" to set the hidden cursor.

---------------------------------
LEFT-HANDED MICE
---------------------------------
Using the control panel, it is possible to change which button on a
mouse generates the "left" and "right" clicks. This feature allows
left-handed people to use their index finger to produce a left click.
This setting causes the touch screen driver to also reverse the
meaning of a touch. Normally, a touch produces a left click. With the
changed setting above, a touch starts producing a right-click.

To address this, edit the file "TwFactory.cfg" in the MT 7 for Windows
software directory. If this file is empty, add in the text:
   <Touch>
   </Touch>

Between these two lines, add a new line:
   SwapMouseButtons=1

Save the file.

Open a command line window and set your working directory to the MT 7
for Windows directory. Issue the command:
   TwCfgUtil /u TwFactory.cfg

At this point, your touches start producing the desired left-clicks.

If your system supports multiple users, you may need to create
separate files, such as TwLeft.cfg and TwRight.cfg. In TwLeft.cfg, set
SwapMouseButtons to 1 and in TwRight.cfg, set SwapMouseButtons to 0.
Add the above TwCfgUtil to each user's Startup menu or login script,
using TwLeft or TwRight as appropriate.

---------------------------------
HELP DOES NOT DISPLAY
---------------------------------
The help file is a PDF file. You need to obtain a PDF viewer or reader
program to view the help file.

-----------------------------------
NO TOUCH FROM PCT DEVELOPMENT UNITS
-----------------------------------
The original PCT development units used an early PX controller that did
not support serial plug-and-play. Starting with version 7.13 Build 2,
the Setup program assumes the use of the newer PX controllers that do
support serial plug-and-play. If you are using a serial interface with
a PCT development system and are using a custom installation, also
select EX serial controller support to regain touch behavior.

------------------------------------------------
MT 7 FOR WINDOWS LEGACY MOUSE DOES NOT HAVE TOUCH
------------------------------------------------
Starting with MT 7.13.14, the driver installation files (INF) no longer
request installation of the Microsoft mouclass.sys driver. The latest
Microsoft certification tests no longer allow the method the INF files
previously used.

Normally, this is not an issue. However, some special system may omit
mouse support. If you install MT 7 for Windows with the 'Legacy Mouse'
driver support on such a system, there will be no touch.

To remedy this, attach a PS/2 or serial mouse to your system. This
forces the installation the needed driver. If you build an embedded
system, include the PS/2 and serial mouse driver.

---------------------------------
REVISION HISTORY
---------------------------------
Version 7.14.9, June 28, 2016
* Added support for new PCT devices.

Version 7.14.8, February 18, 2016
* Added support for new PCT devices.

Version 7.14.7, December 17, 2015
* Added driver support for more touch screen products.
* Addressed a driver halt issue seen with on some systems.

Version 7.14.6, September 28, 2015
* Changed installer technology.
* Added driver support for more touch screen products.
* Added a read feature for TwCfgUtil.exe.
* Addressed possible loss-of-touch issue with USB controllers.
* Addressed issue recognizing some PX serial touch controllers.
* Addressed a minor memory leak seen during calibration. 
* Addressed issue with system halt on some virtual machines.

Version 7.14.4 , July 15, 2014
* Added driver support for more touch screen products

Version 7.14.0 , October 11, 2013
* Added driver support for more touch screen products
* Restructured the driver to better support PX controllers
* The various draw screens now accept multitouch input
* The TwCfgUtil.exe utility program now updates the driver
* Uninstall under Windows 8 now properly removes the MT 7 driver

Version 7.13.14, July 24, 2013
* Added driver support for more touch screen products.
* Added official support for Windows 8.
* Changed driver installation to satisfy new Microsoft requirements.

Version 7.13.13, April 15, 2013
* Improved driver communication for case of USB bus errors
* Right click tool issue resolved for initial installation

Version 7.13.12, January 9, 2013
* Added support for additional PX controllers
* Added new beep support for 64 bit systems

Version 7.13.11, November 27, 2012
* Added support for additional PX controllers
* Driver crash fixed for MT 7 control panel rapid setting changes

Version 7.13.10, October 1, 2012
* Added support for additional PX controllers
* Version information in the control panel is now scrollable and hows
  the version numbers of the drivers
* The driver now switches any PX controller into digitizer mode
* The control panel's restore firmware defaults button no longer
  disrupts the touch on PX USB controllers
* The control panel no longer shows ineffective settings when using the
  digitizer driver
* The installation and uninstallation processes now do a full rescan of
  the system for new devices
* The serial search service no longer crashes on systems with disabled
  serial searches and automatic user login.
* Committing a large volume of individual configuration changes no
  longer crashes the system.

Version 7.13.9, July 25, 2012
* Added support for additional PX controllers.
* The TwMonitor program no longer reacts to screen size changes
  triggered by a remote session. Furthermore, TwMonitor no longer starts
  in a remote session; it only starts in a local user session.

Version 7.13.8, March 21, 2012
* Fixed driver crashes seen in the preview copies of Windows 8 and when
  touching the 'Controller' tab in the MT 7 Control Panel.
* Fixed a memory leak in the TwMonitor program triggered by a change in
  screen resolution.

Version 7.13.7, December 12, 2011
* Added support for additional PX controllers.

Version 7.13.6, October 6, 2011
* Added support for additional PX controllers.
* Updated help file.

Version 7.13.4, June 1, 2011
* Added support for the PX 32" controllers.

Version 7.13.3, December 14, 2010
* The driver problem with Windows XP hangs on reboot or shutdown is 
  fixed.
* The installer defaults to legacy drivers on XP systems.

Version 7.13.2, September 10, 2010
* The MT 7 Software now supports edge adjustments for multi-touch 
  controllers.
* Added support for the PX 19" controllers.
* Improved driver unload for serial controllers.

Version 7.13.1, March 15, 2010
* The installer now queries for the type of driver to install.
* Fixed calibration and linearization issues with the CX controller
* The installer's upgrade feature correctly detects the existing driver.
* Right-click tool works with the HID mouse driver.
* The serial bus driver no longer issues diagnostic messages.
* Fixed the handling of pen and finger frequencies in the SX controller
* Fixed the operating system text in the Control Panel's About dialog.
* Fixed a memory leak triggered by the Monitor program.
* Touch sounds are now handled by the Monitor program.
* A copy of TwFramework.cfg is now installed.
* Changing to the legacy driver deletes the file TwHIDKmdf.sys.
* Uninstall removes old devices created by the Windows HID driver.
* The touch digitizer driver now supports the lift-off touch mode.
* Added support for the production PX controllers.
* Improved sleep mode recovery for serial controllers.

Version 7.13.0, January 22, 2010
* Added support for Windows 7 and Server 2008. Removed support for
  Windows 2000.
* Added support for the PX controllers.
* Changed the driver to report through HID.
* Changed the help file to a PDF.

Version 7.12.6, January 23, 2009
* Support for 64-bit Windows XP, 2003 Server and Vista.
* Addition of support for MicroTouch(tm) CX100 USB.

Version 7.12.5, October 1, 2008
* Upgrade from TouchWare drivers added in installer.
* Addition of support for MicroTouch(tm) EX II HID.
* Full display rotation support added.

Version 7.12.4, July 31, 2008
* Calibration for DST revision 16 controllers introduced.

Version 7.12.3, March 24, 2008
* Windows Vista security issues resolved.
* WePos support added.
* Single display rotation detection added.

Version 7.12.1, September 4, 2007
* All drivers are now certified for Windows Vista.
* Issue 612: Since the drivers are now certified, the installer no
  longer has a problem reacting to a user selecting "Cancel" on the
  dialog asking to install an uncertified driver. Before, the installer
  continued installation.

Version 7.12.0, February 1, 2007
* Multiple monitor and touch screen support now available
* New edge adjustment tool.
* New smaller installer
* Addition of controller reset button
* Support for Windows 2003 Server and Vista.
* Changed the EX II serial controller initialization to include a
  reset command.
* Changed TwService.exe to statically link against the MFC libraries.
* Restored an accidentally deleted feature so that EX II USB
  controllers are now reset when first connected with driver.
* Corrected spelling and grammar mistakes in the calibration library.
* Improved the text out of the calibration library to prevent
  cropping.
* Improved the calibration timeout for USB controllers.
* Calibration temporarily changes the touch mode to "draw" mode during
  calibration. Before, the "draw" test would not work properly.
* Corrected a problem where calibration screens appeared only on the
  first monitor instead of the one being calibrated.
* Added an "/I" command line switch to ignore the last dialog normally
  presented by the standalone calibration tool.
* Changed the label of the controller-specific tabs in the Control
  Panel to "Controller". This used to be the name of the controller
  family. This name is now available on the page itself.
* Reduced the amount of text explaining linearization and frequency
  selection.
* Removed the tooltip (flyover) associated with the "Calibrate" button
  in the control panel.
* Removed the communication port field from the calibration tab of the
  control panel.
* Relabeled the "Controller Information" box to "Support Information"
  on the calibration tab of the control panel.
* Reorganized the old "Reset Software" and "Restore Controller" to be
  included in a box called "Restore Factory Settings". The individual
  buttons are now called "Software" and "Controller".
* Calibration now allows the calibration of a touch screen in a
  multiple monitor situation and there is no corresponding entry for
  it in the configuration database. In such cases, the touch screen is
  assumed to be mapped to the first display.
* Issue 52: The Setup program now displays an hourglass when it is
  working.
* Issue 162: The setup tool now responds to the Cancel button once it
  starts to copy files.
* Issue 182: The uninstall tool now terminates if any MT 7 program is
  running.
* Issue 221: The setup and uninstall tools no longer create any DOS
  windows.
* Issue 253: The uninstaller does not remove any user data files. This
  is done by design.
* Issue 274: The uninstaller now removes any configuration data in the
  registry. Some Windows related entries may remain.
* Issue 342: A silent installation now detects the presence of an old
  copy of TouchWare and terminates if it finds TouchWare.
* Issues 592, 812: There are three touch targets presented during
  calibration. For SC controllers, the third target is for the
  controller's three-point calibration. For other controllers, the
  third target is a software target that does not affect the
  controller's calibration. Before, the calibration terminated with a
  liftoff for SC controllers and a touchdown for other controllers.
  Now, the software waits for a liftoff for all controllers.
* Issue 814: The control panel's "Version Information" tool now shows
  the version number of the TwService.exe program.
* Issue 850, 859: The Touch Monitor program is no longer an option and
  is now always installed.
* Addressed an installer error which disabled calibration if only EX II
  serial support was requested. This was observed on early copies of
  MT 7.12.
* Addressed a calibration problem observed with serial controllers on
  newer, faster CPUs. This was observed on early copies of MT 7.12.
* Addressed an issue where the Control Panel reported the wrong
  frequency for capacitive EX II controllers if the frequency used was
  not one normally supplied by the Control Panel.
* Changed the display of the EX II controller frequency so that it is
  now in whole numbers.
* Addressed an issue where the Multiple Monitor Manager would crash the
  first time it was run on some systems. This was observed on early
  copies of MT 7.12.
* Addressed an issue in the installer which failed to properly create a
  custom installation path during a silent installation. This was
  observed on early copies of MT 7.12.
* A new message now appears when a touch screen controller's frequency
  is changed informing the user not to touch the touch screen.

Version 7.11.2, March 22, 2006
* Improvement of the processing of serial commands while the touch
  screen is being touched.
* Improvement of the serial controller search.
* Improvement of behavior when updating, addressing a problem that
  may hang the system until rebooted.

Version 7.11.1, January 30, 2006
* Addition of support for MicroTouch(tm) DST touch screens
* Removal of support for MicroTouch(tm) IST touch screens

Version 7.11.0, September 7, 2005
* Addition of support for MicroTouch(tm) IST touch screens
* Addition of EX II capacitive frequency settings
* Addition of automated controller search by the installer

Version 7.10.0, March 14, 2005
* Addition of WHQL-certified driver
* Addition of control panel
* Installation allows choice of controller support
* Various other issues addressed

Version 7.00.0, June 20, 2004
* Initial release

________________________________________________________

MicroTouch and the MicroTouch logo are either registered
trademarks or trademarks of 3M in the United States
and/or other countries.

Microsoft and Microsoft Windows are either registered
trademarks or trademarks of Microsoft in the United
States and/or other countries.

________________________________________________________
